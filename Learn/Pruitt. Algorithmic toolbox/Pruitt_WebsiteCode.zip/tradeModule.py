
from indicators import highest,lowest,rsiClass,stochClass

def tradeDecision(date,op,hi,lo,cl,mp,indx):
    buyLevel = highest(hi,10,indx,1)
    if mp != 1 and h >= buyLevel:
        stopLoss = 
        return("Buy",buyLevel,stopLoss,profitObj)

    
    
