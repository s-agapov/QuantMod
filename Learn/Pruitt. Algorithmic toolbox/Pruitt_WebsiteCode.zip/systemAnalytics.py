
def calcSystemResults(systemMarketList):
    masterDateList = list()
    combinedEquity = list()
    monthList = list()
    monthEquity = list()

    for i in range(0,len(systemMarketList)):
        monthList[:] = []
        monthEquity[:] = []
        print("Sys Name : ",systemMarketList[i].systemName)
        print("Mkt Symb : ",systemMarketList[i].symbol)
        print("Profit/Loss : ",systemMarketList[i].profitLoss)
        print("Num Trades : ",systemMarketList[i].numTrades)
        print("Percen Wins : ",systemMarketList[i].perWins)
        print("Avg Win  : ",systemMarketList[i].avgWin)
        print("Avg Loss : ",systemMarketList[i].avgLoss)
        print("Avg Trade: ",systemMarketList[i].avgTrade)
        print("MAX DrawDown: ",systemMarketList[i].equity.maxDD)
        for j in range(0,len(systemMarketList[i].tradesList)):
            systemMarketList[i].tradesList[j].printTrade()
        masterDateList = systemMarketList[i].equity.equityDate    
#        monthList = createMonthList(masterDateList)
#        for j in range(0,len(systemMarketList[i].equity.dailyEquityVal)):
#            print(systemMarketList[i].equity.equityDate[j],' ',systemMarketList[i].equity.dailyEquityVal[j])
        for j in range(0,len(monthList)):
            idx = masterDateList.index(monthList[j])
            if j == 0:
                monthEquity.append(systemMarketList[i].equity.dailyEquityVal[idx])
                prevDailyCum = monthEquity[-1] 
            else:
                whichMonth = monthList[j]
                dailyCum = systemMarketList[i].equity.dailyEquityVal[idx]
                monthEquity.append(dailyCum - prevDailyCum)
                newMonthEquity = dailyCum - prevDailyCum
                prevDailyCum = dailyCum
        for j in range(0,len(monthList)):
            print('%8d %10.0f' % (monthList[j],monthEquity[j]))
            

