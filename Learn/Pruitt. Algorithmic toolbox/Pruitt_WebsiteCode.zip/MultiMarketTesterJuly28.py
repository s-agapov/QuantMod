import csv
import tkinter as tk
import os.path
from getData import getData
#from exitPosition import exitPos
from dataLists import myDate,myTime,myOpen,myHigh,myLow,myClose
from tradeClass import tradeInfo
from equityDataClass import equityClass
from trade import trade
from systemMarket import systemMarketClass
from indicators import highest,lowest,rsiClass,stochClass
from systemAnalytics import calcSystemResults
from tkinter.filedialog import askopenfilenames

def getDataAtribs(dClass):   
   return(dClass.bigPtVal,dClass.symbol,dClass.minMove)
def getDataLists(dClass):
   return(dClass.date,dClass.open,dClass.high,dClass.low,dClass.close)

def calcTodaysOTE(mp,myClose,entryPrice,entryQuant,myBPV):
    todaysOTE = 0
    for entries in range(0,len(entryPrice)):
        if mp >= 1:
            todaysOTE += (myClose - entryPrice[entries])*myBPV*entryQuant[entries]
        if mp <= -1:
           todaysOTE += (entryPrice[entries] - myClose)*myBPV*entryQuant[entries]             
    return(todaysOTE)

def exitPos():
    global mp
    global exitDate,curShares,cumuProfit
    global tradeName,entryPrice,entryQuant,exitPrice,numShares,myBPV
    if mp < 0:
        trades = tradeInfo('liqShort',exitDate,tradeName,exitPrice,numShares)
        profit = trades.calcTradeProfit('liqShort',mp,entryPrice,exitPrice,entryQuant,numShares) * myBPV
        trades.tradeProfit = profit
        trades.cumuProfit += profit

    if mp > 0:
        trades = tradeInfo('liqLong',exitDate,tradeName,exitPrice,numShares) 
        profit = trades.calcTradeProfit('liqLong',mp,entryPrice,exitPrice,entryQuant,numShares) * myBPV
        trades.tradeProfit = profit
        trades.cumuProfit += profit
    curShares = 0
    for remShares in range(0,len(entryQuant)):
       curShares += entryQuant[remShares]
    return (profit,trades,curShares)
     
marketPosition = list()
listOfTrades = list()
dataClassList = list() 
systemMarketList = list()
equityDataList = list()
currentPrice = 0
entryPrice = list()
totComms = 0
fileList = list()
barsSinceEntry = 0
entryPrice = list()
#exitPrice = list()
entryQuant = list()
exitQuant = list()

dataClassList = getData()

numMarkets = len(dataClassList)

numRuns = 0

myBPV = 0

allowPyra = 0

curShares = 0

for marketCnt in range(0,numMarkets):
        listOfTrades[:] = []
        marketPosition[:] = []
        myBPV,myComName,myMinMove = getDataAtribs(dataClassList[marketCnt])
        myDate,myOpen,myHigh,myLow,myClose = getDataLists(dataClassList[marketCnt])
        for i in range(0,len(myDate)):
                marketPosition.append(0)
        systemMarket = systemMarketClass()
        equity = equityClass()
        equItm = 0
        totProfit = 0.0
        maxPositionL = 0
        maxPositionS = 0
        cumuProfit = 0
        for i in range(len(myDate) - 300,len(myDate)):
                equItm += 1
                tempDate = myDate[i]
                todaysCTE = todaysOTE = todaysEquity = 0
                marketPosition[i] = marketPosition[i-1]
                mp = marketPosition[i]
                
 #               todaysOTE = calcTodaysOTE(mp,myClose[i],entryPrice,entryQuant,myBPV)                      

                buyLevel = highest(myHigh,20,i,1)
                sellLevel = lowest(myLow,20,i,1)
                  
        #     rsiVal = rsiStudy.calcRsi(myClose,10,i,1)
        #     fastKVal,fastDVal,slowDVal = stochStudy.calcStochastic(3,9,9,myHigh,myLow,myClose,i,1)               
                
                if (mp > 0 and maxPositionL < 3) : maxPositionL = mp
                if (mp < 0 and maxPositionS < 3) : maxPositionS = mp

                        
 #Long Logic               
                if mp <= 0  and myHigh[i] >= buyLevel:
                        profit = 0
                        if mp <= -1:
                            exitPrice = max(myOpen[i],buyLevel)
                            exitDate = myDate[i]
                            tradeName = "RevShrtLiq"
                            numShares = curShares
                            profit,trades,curPos = exitPos()
                            cumuProfit += profit
                            listOfTrades.append(trades)
                            mp = 0
                            todaysCTE = profit   
                        tradeName = "Buy BO"    
                        mp += 1
                        marketPosition[i] = mp
                        entryPrice.append(max(myOpen[i],buyLevel))
                        numShares = 6
                        entryQuant.append(numShares)
                        curShares = curShares + numShares
                        trades = tradeInfo('buy',myDate[i],tradeName,entryPrice[-1],numShares)
                        barsSinceEntry = 1
                        totProfit += profit   
                        listOfTrades.append(trades)
                        
                if mp > 0 :
                        longLiqLevel = entryPrice[0] -1000 /myBPV
                        if curShares == 6:
                           takeLProf = entryPrice[0] + 2500 /myBPV
                        else:
                           takeLProf = 9999999
                         
                if mp >= 1 and myLow[i] <= longLiqLevel and barsSinceEntry > 1:
                        exitPrice = min(myOpen[i],longLiqLevel)
                        tradeName = "L-MMLoss"
                        exitDate =myDate[i]
                        numShares = curShares
                        exitQuant.append(numShares)
                        profit,trades,curShares = exitPos()
                        cumuProfit += profit
                        if curShares == 0 : mp = marketPosition[i] = 0
                        totProfit += profit
                        todaysCTE = profit
                        listOfTrades.append(trades)
                        maxPositionL = maxPositionL - 1
                        
                if mp >= 1 and myHigh[i] >takeLProf and barsSinceEntry > 1:
                        exitPrice = max(myOpen[i],takeLProf)
                        tradeName = "L-Prof"
                        exitDate = myDate[i]
                        numShares = 2
                        exitQuant.append(numShares)
                        profit,trades,curShares = exitPos()
                        cumuProfit += profit
                        if curShares == 0 : mp = marketPosition[i] = 0
                        totProfit += profit
                        todaysCTE = profit 
                        listOfTrades.append(trades)
                        maxPositionL = maxPositionL -1
# Short Logic                        
                if mp >= 0 and myLow[i] <= sellLevel:
                        profit = 0
                        if mp >= 1:
                            exitPrice = min(myOpen[i],sellLevel)
                            exitDate=myDate[i]
                            tradeName = "RevLongLiq"
                            numShares = curShares
                            profit,trades,curShares = exitPos()
                            cumuProfit += profit
                            todaysCTE = profit   
                            listOfTrades.append(trades)
                            mp = 0
                        mp -= 1
                        tradeName = "Sell BO"
                        marketPosition[i] = mp
                        entryPrice.append(min(myOpen[i],sellLevel))
                        numShares = 6
                        entryQuant.append(numShares)
                        curShares = curShares + numShares 
                        trades = tradeInfo('sell',myDate[i],tradeName,entryPrice[-1],numShares)
                        barsSinceEntry = 1
                        totProfit += profit  
                        listOfTrades.append(trades)
                        
                if mp < 0 :
                        shortLiqLevel = entryPrice[0] +1000 /myBPV
                        if curShares == 6:
                           takeSProf = entryPrice[0] - 2500 /myBPV
                        else:
                           takeSProf = 0
                         
                if mp <= -1 and myHigh[i] >= shortLiqLevel and barsSinceEntry > 1:
                        exitPrice = max(myOpen[i],shortLiqLevel)
                        tradeName = "S-MMLoss"
                        exitDate =myDate[i]
                        numShares = curShares
                        exitQuant.append(numShares)
                        profit,trades,curShares = exitPos()
                        cumuProfit += profit
                        if curShares == 0 : mp = marketPosition[i] = 0
                        totProfit += profit
                        todaysCTE = profit
                        listOfTrades.append(trades)
                        maxPositionS = maxPositionS - 1
                        
                if mp <= -1 and myLow[i] < takeSProf and barsSinceEntry > 1:
                        exitPrice = min(myOpen[i],takeSProf)
                        tradeName = "S-Proff"
                        exitDate = myDate[i]
                        numShares = 2
                        exitQuant.append(numShares)
                        profit,trades,curShares = exitPos()
                        cumuProfit += profit
                        if curShares == 0 : mp = marketPosition[i] = 0
                        totProfit += profit
                        todaysCTE = profit 
                        listOfTrades.append(trades)
                        maxPositionS = maxPositionS -1
                                                                 
                if mp == 0 :
                        todaysOTE = 0
                        curShares = 0
                        entryPrice[:] = []
                        maxPositionL = 0
                        maxPositionS = 0
                if mp != 0 :
                        barsSinceEntry = barsSinceEntry + 1
                        todaysOTE = calcTodaysOTE(mp,myClose[i],entryPrice,entryQuant,myBPV)
                todaysEquity = todaysOTE + totProfit
                equity.setEquityInfo(myDate[i],equItm,todaysCTE,todaysOTE)
        systemMarket.setSysMarkInfo("Bollinger",myComName,listOfTrades,equity)
        systemMarketList.append(systemMarket)
        numRuns = numRuns + 1


calcSystemResults(systemMarketList)


#o.close



