import csv
import tkinter as tk
import os.path
from getData import getData
#from exitPosition import exitPos
from dataLists import myDate,myTime,myOpen,myHigh,myLow,myClose
from tradeClass import tradeInfo
from equityDataClass import equityClass
from trade import trade
from systemMarket import systemMarketClass
from indicators import highest,lowest,rsiClass,stochClass
from systemAnalytics import calcSystemResults
from tkinter.filedialog import askopenfilenames

def getDataAtribs(dClass):   
   return(dClass.bigPtVal,dClass.symbol,dClass.minMove)
def getDataLists(dClass):
   return(dClass.date,dClass.open,dClass.high,dClass.low,dClass.close)

def calcTodaysOTE(mp,myClose,entryPrice,entryQuant,myBPV):
    todaysOTE = 0
    for entries in range(0,len(entryPrice)):
        if mp >= 1:
            todaysOTE += (myClose - entryPrice[entries])*myBPV*entryQuant[entries]
        if mp <= -1:
           todaysOTE += (entryPrice[entries] - myClose)*myBPV*entryQuant[entries]             
    return(todaysOTE)

def exitPos():
    global mp
    global exitDate,curShares
    global tradeName,entryPrice,entryQuant,exitPrice,numShares,myBPV
    if mp < 0:
        trades = tradeInfo('liqShort',exitDate,tradeName,exitPrice,numShares)
        profit = trades.calcTradeProfit('liqShort',mp,entryPrice,exitPrice,entryQuant,numShares) * myBPV
        trades.tradeProfit = profit

    if mp > 0:
        trades = tradeInfo('liqLong',exitDate,tradeName,exitPrice,numShares) 
        profit = trades.calcTradeProfit('liqLong',mp,entryPrice,exitPrice,entryQuant,numShares) * myBPV
        trades.tradeProfit = profit
    curShares = 0
    for remShares in range(0,len(entryQuant)):
       curShares += entryQuant[remShares]
    return (profit,trades,curShares)
     
marketPosition = list()
listOfTrades = list()
dataClassList = list() 
systemMarketList = list()
equityDataList = list()
currentPrice = 0
entryPrice = list()
totComms = 0
fileList = list()
barsSinceEntry = 0
entryPrice = list()
#exitPrice = list()
entryQuant = list()
exitQuant = list()

dataClassList = getData()

numMarkets = len(dataClassList)

numRuns = 0

myBPV = 0

allowPyra = 0

curShares = 0

for marketCnt in range(0,numMarkets):
        listOfTrades[:] = []
        marketPosition[:] = []
        myBPV,myComName,myMinMove = getDataAtribs(dataClassList[marketCnt])
        myDate,myOpen,myHigh,myLow,myClose = getDataLists(dataClassList[marketCnt])
        for i in range(0,len(myDate)):
                marketPosition.append(0)
        systemMarket = systemMarketClass()
        equity = equityClass()
        equItm = 0
        totProfit = 0.0
        maxPositionL = 0
        maxPositionS = 0
        for i in range(len(myDate) - 300,len(myDate)):
                equItm += 1
                tempDate = myDate[i]
                todaysCTE = todaysOTE = todaysEquity = 0
                marketPosition[i] = marketPosition[i-1]
                mp = marketPosition[i]
                
                todaysOTE = calcTodaysOTE(mp,myClose[i],entryPrice,entryQuant,myBPV)                      

                buyLevel = highest(myHigh,4,i,1)
                sellLevel = lowest(myLow,4,i,1)
                  
        #     rsiVal = rsiStudy.calcRsi(myClose,10,i,1)
        #     fastKVal,fastDVal,slowDVal = stochStudy.calcStochastic(3,9,9,myHigh,myLow,myClose,i,1)               
                
                if (mp > 0 and maxPositionL < 3) : maxPositionL = mp
                if (mp < 0 and maxPositionS < 3) : maxPositionS = mp

                        
 #Long Logic               
                if ((mp <= 0 or (allowPyra and maxPositionL < 3)) and myHigh[i]) >= buyLevel:
                        profit = 0
                        buyEntryName = "Buy BO"
                        if mp <= -1:
                            exitPrice = max(myOpen[i],buyLevel)
                            shortLiqName = "RevToLong"
                            numShares = curShares
                            profit,trades = exitPos(mp,myDate[i],shortLiqName,entryPrice,exitPrice,numShares,myBPV)
                            listOfTrades.append(trades)
                        mp += 1
                        marketPosition[i] = mp
                        entryPrice.append(max(myOpen[i],buyLevel))
                        numShares = 6
                        entryQuant.append(numShares)
                        curShares = curShares + numShares
                        trades = tradeInfo('buy',myDate[i],buyEntryName,entryPrice[-1],numShares)
                        print("Going Long: ",myDate[i],' ',entryPrice,' ',myOpen[i])
                        barsSinceEntry = 1
                        totProfit += profit
                        todaysCTE = profit    
                        listOfTrades.append(trades)
                        
                if mp > 0 :
                        longLiqLevel = entryPrice[0] -1000 /myBPV
                        if curShares == 6: takeLProf = entryPrice[0] + 500 /myBPV
                        if curShares == 4: takeLProf = entryPrice[0] + 750 /myBPV
                        if curShares == 2: takeLProf = entryPrice[0] + 900 /myBPV
                         
                if mp >= 1 and myLow[i] <= longLiqLevel and barsSinceEntry > 1:
##                        exitPrice.append(min(myOpen[i],longLiqLevel))
                        exitPrice = min(myOpen[i],longLiqLevel)
                        tradeName = "L-MMLoss"
                        exitDate =myDate[i]
                        numShares = curShares
                        exitQuant.append(numShares)
                        profit,trades,curShares = exitPos()
                        print("Long Loss : ",myDate[i],' ',exitPrice," ",profit,' ',myOpen[i])
                        if curShares == 0 : mp = marketPosition[i] = 0
                        totProfit += profit
                        todaysCTE = profit
                        listOfTrades.append(trades)
                        maxPositionL = maxPositionL - 1
                        
                if mp >= 1 and myHigh[i] >=takeLProf and barsSinceEntry > 1:
##                        exitPrice.append(max(myOpen[i],takeLProf))
                        exitPrice = max(myOpen[i],takeLProf)
                        tradeName = "L-Proff"
                        exitDate = myDate[i]
                        numShares = 2
                        exitQuant.append(numShares)
                        profit,trades,curShares = exitPos()
                        print("Long Prof : ",myDate[i],' ',exitPrice," ",profit,' ',myOpen[i])
                        if curShares == 0 : mp = marketPosition[i] = 0
                        totProfit += profit
                        todaysCTE = profit 
                        listOfTrades.append(trades)
                        maxPositionL = maxPositionL -1
# Short Logic                        
##                if (mp >= 0 or allowPyra) and maxPositionS < 3 and myLow[i] >= sellLevel:
##                        profit = 0
##                        sellEntryName = "sell BO"
##                        if mp <= -1:
##                            exitPrice = min(myOpen[i],sellLevel)
##                            shortLiqName = "RevToShrt"
##                            numShares = curShares
##                            profit,trades = exitPos(mp,myDate[i],shortLiqName,entryPrice,exitPrice,numShares,myBPV)
##                            listOfTrades.append(trades)
##                        mp -= 1
##                        marketPosition[i] = mp
##                        entryPrice.append(min(myOpen[i],sellLevel))
##                        numShares = 1
##                        entryQuant.append(numShares)
##                        curShares = curShares + numShares 
##                        trades = tradeInfo('sell',myDate[i],sellEntryName,entryPrice[-1],numShares)
##                        print("Going Short: ",myDate[i],' ',entryPrice,' ',myOpen[i])
##                        barsSinceEntry = 1
##                        totProfit += profit
##                        todaysCTE = profit    
##                        listOfTrades.append(trades)
##                        
##                if mp < 0 :
##                        shortLiqLevel = entryPrice[0] +1000 /myBPV
##                        takeSProf = entryPrice[0] - 500 /myBPV
##                         
##                if mp <= -1 and myHigh[i] >= shortLiqLevel and barsSinceEntry > 1:
##                        exitPrice.append(max(myOpen[i],shortLiqLevel))
##                        tradeName = "S-MMLoss"
##                        exitDate =myDate[i]
##                        numShares = 1
##                        exitQuant.append(numshares)
##                        profit,trades,curShares = exitPos()
##                        print("Short Loss : ",myDate[i],' ',exitPrice," ",profit,' ',myOpen[i])
##                        mp = marketPosition[i] = curShares
##                        totProfit += profit
##                        todaysCTE = profit
##                        listOfTrades.append(trades)
##                        maxPositionS = maxPositionS - 1
##                        
##                if mp <= -1 and myLow[i] < takeSProf and barsSinceEntry > 1:
##                        exitPrice.append(min(myOpen[i],takeSProf))
##                        tradeName = "S-Proff"
##                        exitDate = myDate[i]
##                        numShares = 1
##                        exitQuant.append(numshares)
##                        profit,trades,curShares = exitPos()
##                        print("Short Prof : ",myDate[i],' ',exitPrice," ",profit,' ',myOpen[i])
##                        mp = marketPosition[i] = curShares
##                        totProfit += profit
##                        todaysCTE = profit 
##                        listOfTrades.append(trades)
##                        maxPositionS = maxPositionS -1
                                                                 
                if mp == 0 :
                        todaysOTE = 0
                        curShares = 0
                        entryPrice[:] = []
##                        exitPrice[:] = []
                        maxPositionL = 0
                        maxPositionS = 0
                if mp != 0 :
                        barsSinceEntry = barsSinceEntry + 1
                        todaysOTE = calcTodaysOTE(mp,myClose[i],entryPrice,entryQuant,myBPV)
                todaysEquity = todaysOTE + totProfit
                equity.setEquityInfo(myDate[i],equItm,todaysCTE,todaysOTE)
        systemMarket.setSysMarkInfo("Bollinger",myComName,listOfTrades,equity)
        systemMarketList.append(systemMarket)
        numRuns = numRuns + 1


calcSystemResults(systemMarketList)


#o.close



