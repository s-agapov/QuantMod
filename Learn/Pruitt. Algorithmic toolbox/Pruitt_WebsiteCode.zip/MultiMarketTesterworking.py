import csv
import tkinter as tk
import os.path
from getData import getData
from exitPosition import exitPos
from dataLists import myDate,myTime,myOpen,myHigh,myLow,myClose
from tradeClass import tradeInfo
from equityDataClass import equityClass
from trade import trade
from systemMarket import systemMarketClass
from indicators import highest,lowest,rsiClass,stochClass
from systemAnalytics import calcSystemResults
from tkinter.filedialog import askopenfilenames

def getDataAtribs(dClass):   
   return(dClass.bigPtVal,dClass.symbol,dClass.minMove)
def getDataLists(dClass):
   return(dClass.date,dClass.open,dClass.high,dClass.low,dClass.close)

     
marketPosition = list()
listOfTrades = list()
dataClassList = list() 
systemMarketList = list()
equityDataList = list()
currentPrice = 0
entryPrice = list()
totComms = 0
fileList = list()
barsSinceEntry = 0

dataClassList = getData()

numMarkets = len(dataClassList)

numRuns = 0

myBPV = 0

for marketCnt in range(0,numMarkets):
   listOfTrades[:] = []
   marketPosition[:] = []
   myBPV,myComName,myMinMove = getDataAtribs(dataClassList[marketCnt])
   myDate,myOpen,myHigh,myLow,myClose = getDataLists(dataClassList[marketCnt])
   for i in range(0,len(myDate)):
      marketPosition.append(0)
   systemMarket = systemMarketClass()
   equity = equityClass()
   equItm = 0
   totProfit = 0.0
   for i in range(len(myDate) - 300,len(myDate)):
      equItm += 1
      tempDate = myDate[i]
      todaysCTE = todaysOTE = todaysEquity = 0
      marketPosition[i] = marketPosition[i-1]
      mp = marketPosition[i]
      if mp == 1:
         todaysOTE = (myClose[i] - entryPrice)*myBPV
      if mp == -1:
         todaysOTE = (entryPrice - myClose[i])*myBPV
         
      buyLevel = highest(myHigh,10,i,1)
      sellLevel = lowest(myLow,10,i,1)
      
#     rsiVal = rsiStudy.calcRsi(myClose,10,i,1)
#     fastKVal,fastDVal,slowDVal = stochStudy.calcStochastic(3,9,9,myHigh,myLow,myClose,i,1)               

      if mp != 1 and myHigh[i] >= buyLevel:
         profit = 0
         buyEntryName = "Boll Buy"
         if mp == -1:
            exitPrice = max(myOpen[i],buyLevel)
            shortLiqName = "RevSLoss"
            profit,trades = exitPos(mp,myDate[i],shortLiqName,entryPrice,exitPrice,numShares,myBPV)
            listOfTrades.append(trades)
         entryPrice = max(myOpen[i],buyLevel)
         longLiqLevel = entryPrice - 1000/myBPV
         numShares = 1
         trades = tradeInfo('buy',myDate[i],buyEntryName,entryPrice,numShares)
         barsSinceEntry = 1
         totProfit += profit
         todaysCTE = profit
         mp = marketPosition[i] = 1        
         listOfTrades.append(trades)
         
      if mp == 1 and myLow[i] <= longLiqLevel and barsSinceEntry > 1:
         exitPrice = min(myOpen[i],longLiqLevel)
         longLiqName = "L-MMLoss"
         profit,trades = exitPos(mp,myDate[i],longLiqName,entryPrice,exitPrice,numShares,myBPV)
         totProfit += profit
         todaysCTE = profit        
         mp = marketPosition[i] = 0
         listOfTrades.append(trades)    
         
      if mp != -1 and myLow[i] <= sellLevel:
         profit = 0
         if mp == 1:
            exitPrice = min(myOpen[i],sellLevel)
            longLiqName = "RevLLoss"
            profit,trades = exitPos(mp,myDate[i],longLiqName,entryPrice,exitPrice,numShares,myBPV)
            listOfTrades.append(trades)
         entryPrice = min(myOpen[i],sellLevel)
         shortLiqLevel = entryPrice + 1000/myBPV
         numShares = 1
         trades = tradeInfo('sell',myDate[i],'Sell Now',entryPrice,numShares)
         barsSinceEntry = 1
         totProfit += profit
         todaysCTE = profit
         mp = marketPosition[i] = -1
         listOfTrades.append(trades)

      if mp == -1 and myHigh[i] >= shortLiqLevel and barsSinceEntry > 1:
         exitPrice = max(myOpen[i],shortLiqLevel)
         shortLiqName = "S-MMLoss"
         profit,trades = exitPos(mp,myDate[i],shortLiqName,entryPrice,exitPrice,numShares,myBPV)
         totProfit += profit
         todaysCTE = profit        
         mp = marketPosition[i] = 0
         listOfTrades.append(trades)

         
      if mp == 0 :
         todaysOTE = 0
      if mp != 0 :
         barsSinceEntry = barsSinceEntry + 1
         if mp == 1:
            todaysOTE = (myClose[i] - entryPrice)*myBPV
         if mp == -1:
            todaysOTE = (entryPrice - myClose[i])*myBPV             
 
      todaysEquity = todaysOTE + totProfit
      equity.setEquityInfo(myDate[i],equItm,todaysCTE,todaysOTE)
   systemMarket.setSysMarkInfo("Bollinger",myComName,listOfTrades,equity)
   systemMarketList.append(systemMarket)
   numRuns = numRuns + 1


calcSystemResults(systemMarketList)


#o.close
