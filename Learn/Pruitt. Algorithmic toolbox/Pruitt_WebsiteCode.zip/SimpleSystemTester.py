import csv
import tkinter as tk
import os.path
from dataLists import myDate,myTime,myOpen,myHigh,myLow,myClose
from dataMasterLists import commName, bigPtVal, minMove
from tradeClass import tradeInfo
from trade import trade
from indicators import highest
from indicators import lowest
from indicators import rsiClass
from indicators import stochClass
from tkinter.filedialog import askopenfilename


      
marketPosition = list()
listOfTrades = list()
myTestList = [1,2,3,4]
currentPrice = 0
entryPrice = 0
totComms = 0
fileName = "dataMaster.csv"
with open(fileName) as f:
   f_csv = csv.reader(f)
   for row in f_csv:
      commName.append(row[0])
      bigPtVal.append(float(row[1]))
      minMove.append(float(row[2]))
      totComms = totComms + 1      
f.close

root = tk.Tk()
root.withdraw()
cnt = 0
fileName = askopenfilename() # show an "Open" dialog box and return the path to the selected file
with open(fileName) as f:
   f_csv = csv.reader(f)
   for row in f_csv:
      myDate.append(int(row[0]))
#      mytime.append(row[2])
      myOpen.append(float(row[1]))
      myHigh.append(float(row[2]))
      myLow.append(float(row[3]))
      myClose.append(float(row[4]))
      marketPosition.append(0)
      cnt = cnt + 1
      
head,tail = os.path.split(fileName)

tempStr = tail[0:2]
for i in range(totComms):
   if tempStr == commName[i]:
      commIndex = i       

   
print("done reading in file")
f.close

with open('C:\outPut.txt','w', newline='') as o:
   spamwriter = csv.writer(o, delimiter=',')
   rsiStudy = rsiClass()
   stochStudy = stochClass()
   for i in range(cnt - 300,cnt):
      buyLevel = highest(myHigh,10,i,1)
      sellLevel = lowest(myLow,10,i,1)
      marketPosition[i] = marketPosition [i-1]
      rsiVal = rsiStudy.calcRsi(myClose,10,i,1)
      fastKVal,fastDVal,slowDVal = stochStudy.calcStochastic(3,9,9,myHigh,myLow,myClose,i,1)
      tempDate = myDate[i]
      if marketPosition[i] != 1 and myHigh[i] >= buyLevel:
         entryPrice = max(myOpen[i],buyLevel)
         profit = trade('buy',entryPrice,marketPosition[i],currentPrice) * bigPtVal[commIndex]
         trades = tradeInfo(myDate[i],"Buy Now",1,entryPrice,profit)
         currentPrice = entryPrice
         marketPosition[i] = 1         
         listOfTrades.append(trades)
         spamwriter.writerow([trades.tradeDate,trades.tradeName,trades.buyOrSell,trades.tradePrice,' ',profit," ",marketPosition[i]])
      if marketPosition[i] != -1 and myLow[i] <= sellLevel:
         entryPrice = min(myOpen[i],sellLevel)
         profit = trade('sell',entryPrice,marketPosition[i],currentPrice) * bigPtVal[commIndex]
         trades = tradeInfo(myDate[i],"Sell Now",1,entryPrice,profit)
         currentPrice = entryPrice
         marketPosition[i] = -1         
         listOfTrades.append(trades)
         spamwriter.writerow([myDate[i]," Sell ",entryPrice,' ',profit," ",marketPosition[i]])

   for index in range(1,len(listOfTrades)):
      listOfTrades[index].printTrade()
         
o.close



