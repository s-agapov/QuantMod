
D = curBar
D1 = curBar - 1
D2 = curBar - 2
D3 = curBar - 3
D4 = curBar - 4
D5 = curBar - 5
