import csv
import tkinter as tk
import os.path
from marketDataClass import marketDataClass
from dataMasterLists import commName, bigPtVal, minMove
from tkinter.filedialog import askopenfilenames
from equityDataClass import equityClass

dataClassList = list()

fileName = "c:\PythonBackTester\dataMaster.csv"

def getData():
    totComms = 0
    with open(fileName) as f:
       f_csv = csv.reader(f)
       for row in f_csv:
          commName.append(row[0])
          bigPtVal.append(float(row[1]))
          minMove.append(float(row[2]))
          totComms = totComms + 1      
    f.close
    root = tk.Tk()
    root.withdraw()
    cnt = 0
    files = askopenfilenames(filetypes=(('CSV files', '*.txt'),
                                       ('All files', '*.*')),
                                       title='Select Markets To Test')
    fileList = root.tk.splitlist(files)
    fileListLen = len(fileList)
    for marketCnt in range(0,fileListLen):
        head,tail = os.path.split(fileList[marketCnt])
        tempStr = tail[0:2]
        for i in range(totComms):
            if tempStr == commName[i]:
                commIndex = i
        newDataClass = marketDataClass()
        newDataClass.setDataAttributes(commName[commIndex],bigPtVal[commIndex],minMove[commIndex])
        with open(fileList[marketCnt]) as f:     
            f_csv = csv.reader(f)
            for row in f_csv:
                newDataClass.readData(int(row[0]),float(row[1]),float(row[2]),float(row[3]),float(row[4]),0.0,0.0)                              
                cnt = cnt + 1
        dataClassList.append(newDataClass)
        f.close
    return(dataClassList)
 
