import csv
import tkinter as tk
import os.path
from getData import getData
#from exitPosition import exitPos
from dataLists import myDate,myTime,myOpen,myHigh,myLow,myClose
from tradeClass import tradeInfo
from equityDataClass import equityClass
from trade import trade
from systemMarket import systemMarketClass
from portfolio import portfolioClass
from indicators import highest,lowest,rsiClass,stochClass,sAverage
from systemAnalytics import calcSystemResults
from tkinter.filedialog import askopenfilenames

def getDataAtribs(dClass):   
   return(dClass.bigPtVal,dClass.symbol,dClass.minMove)
def getDataLists(dClass):
   return(dClass.date,dClass.open,dClass.high,dClass.low,dClass.close)

def calcTodaysOTE(mp,myClose,entryPrice,entryQuant,myBPV):
    todaysOTE = 0
    for entries in range(0,len(entryPrice)):
        if mp >= 1:
            todaysOTE += (myClose - entryPrice[entries])*myBPV*entryQuant[entries]
        if mp <= -1:
           todaysOTE += (entryPrice[entries] - myClose)*myBPV*entryQuant[entries]             
    return(todaysOTE)

def exitPos(myExitPrice,myExitDate,tempName,myCurShares):
    global mp
#    global exitDate,curShares,
    global tradeName,entryPrice,entryQuant,exitPrice,numShares,myBPV,cumuProfit

    print(myExitDate," ",mp," ",myCurShares," ",tempName)
    if mp < 0:
        trades = tradeInfo('liqShort',myExitDate,tempName,myExitPrice,myCurShares,0)
        profit = trades.calcTradeProfit('liqShort',mp,entryPrice,myExitPrice,entryQuant,myCurShares) * myBPV
        trades.tradeProfit = profit
        cumuProfit += profit
        trades.cumuProfit = cumuProfit
    if mp > 0:
        trades = tradeInfo('liqLong',myExitDate,tempName,myExitPrice,myCurShares,0) 
        profit = trades.calcTradeProfit('liqLong',mp,entryPrice,myExitPrice,entryQuant,myCurShares) * myBPV
        trades.tradeProfit = profit
        cumuProfit += profit
        trades.cumuProfit = cumuProfit
    curShares = 0
    for remShares in range(0,len(entryQuant)):
       curShares += entryQuant[remShares]
    return (profit,trades,curShares)

   
marketPosition = list()
listOfTrades = list()
trueRanges = list()
ranges = list()
dataClassList = list() 
systemMarketList = list()
equityDataList = list()
currentPrice = 0
entryPrice = list()
totComms = 0
fileList = list()
barsSinceEntry = 0
entryPrice = list()
#exitPrice = list()
entryQuant = list()
exitQuant = list()

dataClassList = getData()

numMarkets = len(dataClassList)

numRuns = 0

myBPV = 0

allowPyra = 0

curShares = 0

portfolio = portfolioClass()

for marketCnt in range(0,numMarkets):
 ###########  DO NOT CHANGE BELOW ################################################################   
        listOfTrades[:] = []
        marketPosition[:] = []
        entryPrice[:] = []
        entryQuant[:] = []
        exitQuant[:] = []
        trueRanges[:] = []
        myBPV,myComName,myMinMove = getDataAtribs(dataClassList[marketCnt])
        myDate,myOpen,myHigh,myLow,myClose = getDataLists(dataClassList[marketCnt])
        for i in range(0,len(myDate)):
                marketPosition.append(0)
                ranges.append(myHigh[i] - myLow[i])
                if i == 0:
                   trueRanges.append(ranges[i])
                if i > 0:
                   trueRanges.append(max(myClose[i-1],myHigh[i]) - min(myClose[i-1],myLow[i]))
        systemMarket = systemMarketClass()
        equity = equityClass()
        equItm = 0
        totProfit = 0.0
        maxPositionL = 0
        maxPositionS = 0
        cumuProfit = 0
        curShares = 0
        numShares = 0
        rsiStudy = rsiClass()
        for i in range(len(myDate) - 100,len(myDate)):           
                equItm += 1
                tempDate = myDate[i]
                todaysCTE = todaysOTE = todaysEquity = 0
                marketPosition[i] = marketPosition[i-1]
                mp = marketPosition[i]                
 ###########  DO NOT CHANGE ABOVE ################################################################
                buyLevel = highest(myHigh,20,i,1)
                sellLevel = lowest(myLow,20,i,1)
                atrVal = sAverage(trueRanges,10,i,0)                  
                rsiVal = rsiStudy.calcRsi(myClose,10,i,0)
#                print(myDate[i],"rsi ",rsiVal," atrVal ",atrVal*myBPV," ",myBPV)
#            fastKVal,fastDVal,slowDVal = stochStudy.calcStochastic(3,9,9,myHigh,myLow,myClose,i,1)               
                
#                if (mp > 0 and maxPositionL < 3) : maxPositionL = mp
#                if (mp < 0 and maxPositionS < 3) : maxPositionS = mp

                        
 #Long Entry Logic               
                if mp <= 0  and rsiVal < 30:
                        profit = 0
                        price = myClose[i]
                        if mp <= -1:
                            profit,trades,curShares = exitPos(price,myDate[i],"RevShrtLiq",curShares)
                            listOfTrades.append(trades)
                            mp = 0
                            todaysCTE = profit   
                        tradeName = "RSI Buy"    
                        mp += 1
                        marketPosition[i] = mp                       
                        numShares = 1
                        entryPrice.append(price)
                        entryQuant.append(numShares)
                        curShares = curShares + numShares
                        trades = tradeInfo('buy',myDate[i],tradeName,entryPrice[-1],numShares,1)
                        barsSinceEntry = 1
                        totProfit += profit   
                        listOfTrades.append(trades)
 #Long Exit - Loss                                                 
                if mp >= 1 and myClose[i] < entryPrice[-1] - atrVal and barsSinceEntry > 1:
                        price = myClose[i]
                        tradeName = "L-MMLoss"
                        exitDate =myDate[i]
                        numShares = curShares
                        exitQuant.append(numShares)
                        profit,trades,curShares = exitPos(price,myDate[i],tradeName,numShares)
                        if curShares == 0 : mp = marketPosition[i] = 0
                        totProfit += profit
                        todaysCTE = profit
                        listOfTrades.append(trades)
                        maxPositionL = maxPositionL - 1
 # Long Exit - Profit                       
                if mp >= 1 and myClose[i] > entryPrice[-1] + 3 *atrVal and barsSinceEntry > 1:
                        price = myClose[i]
                        tradeName = "L-Prof"
                        numShares = curShares
                        exitQuant.append(numShares)
                        profit,trades,curShares = exitPos(price,myDate[i],tradeName,numShares)
                        if curShares == 0 : mp = marketPosition[i] = 0
                        totProfit += profit
                        todaysCTE = profit 
                        listOfTrades.append(trades)
                        maxPositionL = maxPositionL -1
# Short Logic                        
                if mp >= 0 and rsiVal > 70:
                        profit = 0
                        price = myClose[i]
                        if mp >= 1:
                            profit,trades,curShares = exitPos(price,myDate[i],"RevLongLiq",curShares) 
                            todaysCTE = profit   
                            listOfTrades.append(trades)
                            mp = 0
                        mp -= 1
                        tradeName = "RSI Short"
                        marketPosition[i] = mp
                        entryPrice.append(price)
                        numShares = 1
                        entryQuant.append(numShares)
                        curShares = curShares + numShares
                        trades = tradeInfo('sell',myDate[i],tradeName,entryPrice[-1],numShares,1)
                        barsSinceEntry = 1
                        totProfit += profit  
                        listOfTrades.append(trades)
# Short Exit Loss                                                
                if mp <= -1 and myClose[i] > entryPrice[-1] + atrVal and barsSinceEntry > 1:
                        price = myClose[i]
                        tradeName = "S-MMLoss"
                        exitDate =myDate[i]
                        numShares = curShares
                        exitQuant.append(numShares)
                        profit,trades,curShares = exitPos(price,myDate[i],tradeName,numShares) 
                        if curShares == 0 : mp = marketPosition[i] = 0
                        totProfit += profit
                        todaysCTE = profit
                        listOfTrades.append(trades)
                        maxPositionS = maxPositionS - 1
# Short Exit Profit                      
                if mp <= -1 and myClose[i] < entryPrice[-1] - 3 *atrVal and barsSinceEntry > 1:
                        price = myClose[i]
                        tradeName = "S-Proff"
                        exitDate = myDate[i]
                        numShares = curShares
                        exitQuant.append(numShares)
                        profit,trades,curShares = exitPos(price,myDate[i],tradeName,numShares) 
                        if curShares == 0 : mp = marketPosition[i] = 0
                        totProfit += profit
                        todaysCTE = profit 
                        listOfTrades.append(trades)
                        maxPositionS = maxPositionS -1
 ###########  DO NOT CHANGE BELOW ################################################################                                                               
                if mp == 0 :
                        todaysOTE = 0
                        curShares = 0
                        entryPrice[:] = []
                        maxPositionL = 0
                        maxPositionS = 0
                if mp != 0 :
                        barsSinceEntry = barsSinceEntry + 1
                        todaysOTE = calcTodaysOTE(mp,myClose[i],entryPrice,entryQuant,myBPV)
                todaysEquity = todaysOTE + totProfit
                equity.setEquityInfo(myDate[i],equItm,todaysCTE,todaysOTE)                
        if mp >= 1:
            price = myClose[i]
            tradeName = "L-EOD"
            exitDate =myDate[i]
            numShares = curShares
            exitQuant.append(numShares)
            profit,trades,curShares = exitPos(price,myDate[i],tradeName,numShares)
            listOfTrades.append(trades)
        if mp <= -1:
            price = myClose[i]
            tradeName = "S-EOD"
            exitDate =myDate[i]
            numShares = curShares
            exitQuant.append(numShares)
            profit,trades,curShares = exitPos(price,myDate[i],tradeName,numShares)
            listOfTrades.append(trades)
        systemMarket.setSysMarkInfo("UGTATSrsi1",myComName,listOfTrades,equity)
        systemMarketList.append(systemMarket)
        numRuns = numRuns + 1
        
portfolio.setPortfolioInfo("PortfolioTest",systemMarketList)

calcSystemResults(systemMarketList)


#o.close



