import csv
import tkinter as tk
import os.path
from marketDataClass import marketDataClass
from dataLists import myDate,myTime,myOpen,myHigh,myLow,myClose
from dataMasterLists import commName, bigPtVal, minMove
from tradeClass import tradeInfo
from equityDataClass import equityClass
from trade import trade
from systemMarket import systemMarketClass
from indicators import highest
from indicators import lowest
from indicators import rsiClass
from indicators import stochClass
from systemAnalytics import calcSystemResults
from tkinter.filedialog import askopenfilenames



'''def buy(ePrice,shares,eDate,name,tradeClass):
   profit = 0
   if tradeClass.currentPos == -1:
      tradeClass.setTradeInfo('shortLiq',eDate,'ShortExit',ePrice,shares)
      profit = tradeClass.tradeProfit
   tradeClass = tradeInfo()
   tradeClass.setTradeInfo('buy',eDate,'Buy Now',ePrice,shares)
   return(profit,tradeClass)

def sell(ePrice,shares,eDate,name,tradeClass):
   profit = 0
   if tradeClass.currentPos == 1:
      tradeClass.setTradeInfo('longLiq',eDate,'longExit',ePrice,shares)
      profit = tradeClass.tradeProfit
   tradeClass = tradeInfo()
   tradeClass.setTradeInfo('sell',eDate,'Sell Now',ePrice,shares)
   return(profit,tradeClass)'''
      
marketPosition = list()
listOfTrades = list()
dataClassList = list()
systemMarketList = list()
equityDataList = list()
currentPrice = 0
entryPrice = list()
totComms = 0
fileList = list()
fileName = "dataMaster.csv"


with open(fileName) as f:
   f_csv = csv.reader(f)
   for row in f_csv:
      commName.append(row[0])
      bigPtVal.append(float(row[1]))
      minMove.append(float(row[2]))
      totComms = totComms + 1      
f.close
root = tk.Tk()
root.withdraw()
cnt = 0
files = askopenfilenames(filetypes=(('CSV files', '*.txt'),
                                       ('All files', '*.*')),
                                       title='Select Markets To Test')
fileList = root.tk.splitlist(files)
fileListLen = len(fileList)
for marketCnt in range(0,fileListLen):
   head,tail = os.path.split(fileList[marketCnt])
   tempStr = tail[0:2]
   for i in range(totComms):
      if tempStr == commName[i]:
         commIndex = i
   newDataClass = marketDataClass()
   newDataClass.setDataAttributes(commName[commIndex],bigPtVal[commIndex],minMove[commIndex])
   with open(fileList[marketCnt]) as f:     
      f_csv = csv.reader(f)
      for row in f_csv:
         marketPosition.append(0)
         newDataClass.readData(int(row[0]),float(row[1]),float(row[2]),float(row[3]),float(row[4]),0.0,0.0)                              
         cnt = cnt + 1
   dataClassList.append(newDataClass)
f.close
numMarkets = len(fileList)
numRuns = 0
for marketCnt in range(0,numMarkets):
   listOfTrades[:] = []
   myBPV = dataClassList[marketCnt].bigPtVal
   myComName = dataClassList[marketCnt].symbol
   myDate = dataClassList[marketCnt].date
   myOpen = dataClassList[marketCnt].open
   myHigh = dataClassList[marketCnt].high
   myLow = dataClassList[marketCnt].low
   myClose = dataClassList[marketCnt].close
   systemMarket = systemMarketClass()
   equity = equityClass()
   equItm = 0
   totProfit = 0.0
   for i in range(len(myDate) - 300,len(myDate)):
      equItm += 1
      if equItm == 1:
         trades = tradeInfo()
      buyLevel = highest(myHigh,10,i,1)
      sellLevel = lowest(myLow,10,i,1)
      marketPosition[i] = marketPosition [i-1]
#         rsiVal = rsiStudy.calcRsi(myClose,10,i,1)
#         fastKVal,fastDVal,slowDVal = stochStudy.calcStochastic(3,9,9,myHigh,myLow,myClose,i,1)
      tempDate = myDate[i]
      todaysOTE = 0
      todaysCTE = 0
      todaysEquity = 0
      mp = marketPosition[i]

      if len(entryPrice) > 0:
         if mp == 1:
            todaysOTE = (myClose[i] - entryPrice[-1])*myBPV
         if mp == -1:
            todaysOTE = (entryPrice[-1] - myClose[i])*myBPV
         
      if mp != 1 and myHigh[i] >= buyLevel:
         entryPrice.append(max(myOpen[i],buyLevel))
         numShares = 1
         if mp == -1:
            trades.setTradeInfo('liqShort',myDate[i],'liqSREv',entryPrice,numShares)
            totProfit += trades.tradeProfit
            todaysCTE = trades.tradeProfit
            listOfTrades.append(trades) 
         trades = tradeInfo()
         trades.setTradeInfo('buy',myDate[i],'Buy Now',entryPrice,numShares)
         totProfit += trades.tradeProfit
         todaysCTE = trades.tradeProfit        
         marketPosition[i] = 1         
         listOfTrades.append(trades)
         todaysOTE =(myClose[i] - entryPrice[-1]) * myBPV
         
      if marketPosition[i] != -1 and myLow[i] <= sellLevel:
         entryPrice.append(min(myOpen[i],sellLevel))
         numShares = 1
         if mp == 1:
            trades.setTradeInfo('liqLong',myDate[i],'liqLREv',entryPrice,numShares)
            totProfit += trades.tradeProfit
            todaysCTE = trades.tradeProfit
            listOfTrades.append(trades) 
         trades = tradeInfo()
         trades.setTradeInfo('sell',myDate[i],'Sell Now',entryPrice,numShares)
         totProfit += trades.tradeProfit
         todaysCTE = trades.tradeProfit
         marketPosition[i] = -1         
                
         todaysOTE = (entryPrice[-1] - myClose[i]) * myBPV
         
      todaysEquity = todaysOTE + totProfit
      equity.setEquityInfo(myDate[i],equItm,todaysCTE,todaysOTE)
   systemMarket.setSysMarkInfo("Bollinger",myComName,listOfTrades,equity)
   systemMarketList.append(systemMarket)
   numRuns = numRuns + 1

"""for i in range(0,len(systemMarketList)):
   print("Sys Name : ",systemMarketList[i].systemName)
   print("Mkt Symb : ",systemMarketList[i].symbol)
   numTrades = len(systemMarketList[i].tradesList)
   for j in range(0,len(systemMarketList[i].tradesList)):
      systemMarketList[i].tradesList[j].printTrade()
   ref = systemMarketList[i].equity
   for j in range(0,len(ref.equityDate)):     
      print(ref.equityDate[j],ref.equityItm[j],ref.dailyEquityVal[j],ref.maxDD)
#   print (ref.cumuEquity)

#   for j in range(0,len(systemMarketList[i].equityList)):
#      systemMarketList[i].equityList[j'"""
calcSystemResults(systemMarketList)   




