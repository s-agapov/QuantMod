
commName = list()
bigPtVal = list()
minMove = list()
