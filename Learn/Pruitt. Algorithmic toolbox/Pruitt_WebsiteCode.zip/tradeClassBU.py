
class tradeInfo(object):
    def __init__(self):
        self.entryPrice = list()
        self.entryName = list()
        self.exitPrice = list()
        self.exitName = list()
        self.entryDate = list()
        self.exitDate = list()
        self.entryQuant = list()
        self.exitQuant = list()
        self.currentPos = list()
        self.tradeProfit = list()
        
    
        
    def setTradeInfo(self,tradeOrder,tradeDate,tradeName,tradePrice,quant):

        def calcTradeProfit(curPos):
            profit = 0
            testLen = len(self.tradePrice)
            if testLen > 1:
                actionPrice = self.tradePrice[len(self.tradePrice)-1]
                curEntryPrice = self.tradePrice[len(self.tradePrice)-2]
                if self.tradeOrder == 'buy':
                    if curPos == -1:
                        profit = (curEntryPrice - actionPrice) * self.quant
                elif self.tradeOrder == 'sell':
                    if curPos == 1:
                        profit = (actionPrice - curEntryPrice) * self.quant
                elif self.tradeOrder == 'liqLong':
                    if curPos == 1:
                        profit = (actionPrice - curEntryPrice) * self.quant
                elif self.tradeOrder == 'liqShort':
                    if curPos == -1:
                        profit = (curEntryPrice - actionPrice) *self.quant
            self.tradeProfit.append(profit)
    #        return profit    

        if tradeOrder == 'buy':
            self.entryName.append(tradeName)
            self.entryPrice.append(tradePrice
            self.entryQuant.append(quant
            self.entryDate.append(tradeDate
            if self.currentPos == -1:
                calcTradeProfit(self.currentPos)
            self.currentPos = 1
        if tradeOrder == 'sell':
            self.entryName = tradeName
            self.entryPrice = tradePrice
            self.entryQuant = quant
            self.entryDate = tradeDate
            if self.currentPos == 1:
                calcTradeProfit(self.currentPos)
            self.currentPos = -1
        if tradeOrder == 'liqLong':
            self.exitName = tradeName
            self.exitPrice = tradePrice
            self.exitQuant = quant
            self.exitDate = tradeDate
            calcTradeProfit(self.currentPos)
            self.currentPos = 0
        if tradeOrder =='liqShort':
            self.exitName = tradeName
            self.exitPrice = tradePrice
            self.exitQuant = quant
            self.exitDate = tradeDate
            calcTradeProfit(self.currentPos)
            self.currentPos = 0
            
        

    def printTrade(self):
        print(self.tradeDate,' ',self.tradeName,' ',self.quant,' ',self.tradePrice,' ',self.tradeProfit)
