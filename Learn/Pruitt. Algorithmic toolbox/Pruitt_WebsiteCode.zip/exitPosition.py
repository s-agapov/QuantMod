from tradeClass import tradeInfo

#def exitPos(mp,exitDate,tradeName,entryPrice,exitPrice,numShares,myBPV):
def exitPos():
    global mp
    global exitDate,tradeName,entryPrice,exitPrice,numShares,myBPV
    if mp == -1:
        trades = tradeInfo('liqShort',exitDate,tradeName,exitPrice,numShares)
        profit = trades.calcTradeProfit('liqShort',mp,entryPrice,exitPrice) * myBPV
        trades.tradeProfit = profit
    if mp == 1:
        trades = tradeInfo('liqLong',exitDate,tradeName,exitPrice,numShares) 
        profit = trades.calcTradeProfit('liqLong',mp,entryPrice,exitPrice) * myBPV
        trades.tradeProfit = profit    
    return (profit,trades)
 
